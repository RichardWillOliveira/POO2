public class PerguntaMultEscolha extends Pergunta {
    private String[] opcoes;

    public PerguntaMultEscolha() {
    }



    public String[] getOpcoes() {
        return opcoes;
    }

    public void setOpcoes(String[] opcoes) {
        this.opcoes = opcoes;
    }
}
