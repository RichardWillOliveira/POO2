
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;
public class Main {
public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);

    System.out.println("Bem vindo ao Show do milhão!!");
    System.out.print("");
    System.out.print("Digite o nome do jogador: ");
    String PlayerName = sc.nextLine();
    System.out.print("");

    System.out.print("Digite o nome do save: ");
    String save = sc.nextLine()+".txt";
    System.out.print("");

    System.out.println("Escolha: 1 I 2 I 3 I 4");

    PerguntaMultEscolha pergunta1 = new PerguntaMultEscolha();
    pergunta1.setPergunta("Qual o livro mais vendido no mundo a seguir à Bíblia?");
    pergunta1.setResposta("2");
    pergunta1.setOpcoes(new String[]{"O Senhor dos Anéis", "Dom Quixote", "O Pequeno Príncipe", "Um Conto de Duas Cidades"});
    pergunta1.setPontos(100);

    PerguntaMultEscolha pergunta2 = new PerguntaMultEscolha();
    pergunta2.setPergunta("De quem é a famosa frase “Penso, logo existo”?");
    pergunta2.setResposta("3");
    pergunta2.setOpcoes(new String[]{"Platão", "Galileu Galilei", "Descartes", "Sócrates"});
    pergunta2.setPontos(100);

    PerguntaMultEscolha pergunta3 = new PerguntaMultEscolha();
    pergunta3.setPergunta("Qual o número mínimo de jogadores em cada time numa partida de futebol?");
    pergunta3.setResposta("3");
    pergunta3.setOpcoes(new String[]{"8", "10", "7", "9"});
    pergunta3.setPontos(100);

    PerguntaMultEscolha pergunta4 = new PerguntaMultEscolha();
    pergunta4.setPergunta("Qual a nacionalidade de Che Guevara?");
    pergunta4.setResposta("4");
    pergunta4.setOpcoes(new String[]{"Cubana", "Peruana", "Boliviana", "Argentina"});
    pergunta4.setPontos(100);

    PerguntaMultEscolha pergunta5 = new PerguntaMultEscolha();
    pergunta5.setPergunta("Em que período da pré-história o fogo foi descoberto?");
    pergunta5.setResposta("1");
    pergunta5.setOpcoes(new String[]{"Paleolítico", "Neolítico", "Idade Média", "Idade dos Metais"});
    pergunta5.setPontos(100);

    PerguntaMultEscolha pergunta6 = new PerguntaMultEscolha();
    pergunta6.setPergunta("Qual destes países é transcontinental?");
    pergunta6.setResposta("1");
    pergunta6.setOpcoes(new String[]{"Rússia", "Filipinas", "Marrocos", "Groenlandia"});
    pergunta6.setPontos(100);

    PerguntaMultEscolha pergunta7 = new PerguntaMultEscolha();
    pergunta7.setPergunta("Júpiter é correlato romano de qual deus grego?");
    pergunta7.setResposta("4");
    pergunta7.setOpcoes(new String[]{"Ares", "Cronos", "Apolo", "Zeus"});
    pergunta7.setPontos(100);

    PerguntaMultEscolha pergunta8 = new PerguntaMultEscolha();
    pergunta8.setPergunta("As pessoas de qual tipo sanguíneo são consideradas doadores universais?");
    pergunta8.setResposta("3");
    pergunta8.setOpcoes(new String[]{"A", "B", "O", "AB"});
    pergunta8.setPontos(100);

    PerguntaMultEscolha pergunta9 = new PerguntaMultEscolha();
    pergunta9.setPergunta("Como se chamam os vasos que transportam sangue do coração para a periferia do corpo?");
    pergunta9.setResposta("2");
    pergunta9.setOpcoes(new String[]{"Veias", "Artérias", "Ventrículos", "Aurículos"});
    pergunta9.setPontos(100);

    PerguntaMultEscolha pergunta10 = new PerguntaMultEscolha();
    pergunta10.setPergunta("Como forma de resistir às tradições do Halloween, qual a data comemorativa foi instituída no Brasil para ser celebrada no dia 31 de outubro?");
    pergunta10.setResposta("1");
    pergunta10.setOpcoes(new String[]{"Dia do Saci", "Dia das Bruxas", "Dia do Folclore", "Dia da Música Popular Brasileira"});
    pergunta10.setPontos(100);

    PerguntaMultEscolha pergunta11 = new PerguntaMultEscolha();
    pergunta11.setPergunta("O Dia Mundial do Maior Mamífero Terreste do Brasil homenageia a Anta, está correto?");
    pergunta11.setResposta("1");
    pergunta11.setOpcoes(new String[]{"Verdadeiro", "Falso"});
    pergunta11.setPontos(100);

    PerguntaMultEscolha pergunta12 = new PerguntaMultEscolha();
    pergunta12.setPergunta("Tomar leite antes de deitar na cama, ajuda na inicialização e qualidade do sono?");
    pergunta12.setResposta("1");
    pergunta12.setOpcoes(new String[]{"Verdadeiro", "Falso"});
    pergunta12.setPontos(100);

    PerguntaMultEscolha pergunta13 = new PerguntaMultEscolha();
    pergunta13.setPergunta("O Dublador Ricardo Juarez, interpretou a voz de Kratos de God Of War e Melman de Madasgascar?");
    pergunta13.setResposta("1");
    pergunta13.setOpcoes(new String[]{"Verdadeiro", "Falso"});
    pergunta13.setPontos(100);

    PerguntaMultEscolha pergunta14 = new PerguntaMultEscolha();
    pergunta14.setPergunta("O filme Avatar: O Caminho da Água superou o filme Titanic em bilheterias da história?");
    pergunta14.setResposta("1");
    pergunta14.setOpcoes(new String[]{"Verdadeiro", "Falso"});
    pergunta14.setPontos(100);

    PerguntaMultEscolha pergunta15 = new PerguntaMultEscolha();
    pergunta15.setPergunta("A cantora Jen Ledger entrou para a banda de rock Skillet, conhecendo os lideres do grupo em local de evento religioso?");
    pergunta15.setResposta("1");
    pergunta15.setOpcoes(new String[]{"Verdadeiro", "Falso"});
    pergunta15.setPontos(100);

    PerguntaMultEscolha pergunta16 = new PerguntaMultEscolha();
    pergunta16.setPergunta("O jogador conhecido como Lionel Messi é classificado pelo voto popular como o jogador mais influente da Champions League na era moderna?");
    pergunta16.setResposta("2");
    pergunta16.setOpcoes(new String[]{"Verdadeiro", "Falso"});
    pergunta16.setPontos(100);

    PerguntaMultEscolha pergunta17 = new PerguntaMultEscolha();
    pergunta17.setPergunta("Atualmente o Instagram ocupa o 2ºlugar de redes sociais mais utilizadas no mundo?");
    pergunta17.setResposta("2");
    pergunta17.setOpcoes(new String[]{"Verdadeiro", "Falso"});
    pergunta17.setPontos(100);

    PerguntaMultEscolha pergunta18 = new PerguntaMultEscolha();
    pergunta18.setPergunta("A luta mais longa da história do UFC durou 5h40min?");
    pergunta18.setResposta("2");
    pergunta18.setOpcoes(new String[]{"Verdadeiro", "Falso"});
    pergunta18.setPontos(100);

    PerguntaMultEscolha pergunta19 = new PerguntaMultEscolha();
    pergunta19.setPergunta("A pedra mais rara do mundo é o berílio vermelho,sendo mais dificil de ser encontrada do que os rubis.A afirmação é?");
    pergunta19.setResposta("2");
    pergunta19.setOpcoes(new String[]{"Verdadeiro", "Falso"});
    pergunta19.setPontos(100);

    PerguntaMultEscolha pergunta20 = new PerguntaMultEscolha();
    pergunta20.setPergunta("O japão possui a maior expectativa de vida, respectivamente com 79 anos de idade.A Afirmação é");
    pergunta20.setResposta("2");
    pergunta20.setOpcoes(new String[]{"Verdadeiro", "Falso"});
    pergunta20.setPontos(100);

    Pergunta[] perguntas = {pergunta1, pergunta2, pergunta3, pergunta4, pergunta5, pergunta6, pergunta7, pergunta8, pergunta9, pergunta10, pergunta11, pergunta12, pergunta13, pergunta14, pergunta15, pergunta16, pergunta17, pergunta18, pergunta19, pergunta20};

    Player Player = new Player();
    Player.setNome(PlayerName);
    Player.setPontos(0);

    try (BufferedWriter writer = new BufferedWriter(new FileWriter(save))) {
        Random random = new Random();

        for (int i = 0; i < 10; i++) {
            int indicePergunta = random.nextInt(perguntas.length - i);
            Pergunta pergunta = perguntas[indicePergunta];
            perguntas[indicePergunta] = perguntas[perguntas.length - i - 1];

            writer.write("Pergunta: " + pergunta.getPergunta() + "\n");

            if (pergunta instanceof PerguntaMultEscolha) {
                PerguntaMultEscolha perguntaMultEscolha = (PerguntaMultEscolha) pergunta;
                writer.write("Opções: " + String.join(", ", perguntaMultEscolha.getOpcoes()) + "\n");
            }writer.write("Resposta: " + pergunta.getResposta() + "\n");
            writer.write("Pontuação: " + pergunta.getPontos() + "\n\n");
            writer.flush();

            System.out.println(pergunta.getPergunta());
            if (pergunta instanceof PerguntaMultEscolha) {
                PerguntaMultEscolha perguntaMultEscolha = (PerguntaMultEscolha) pergunta;
                String[] opcoes = perguntaMultEscolha.getOpcoes();
                for (int j = 0; j < opcoes.length; j++) {
                    System.out.println((j + 1) + ". " + opcoes[j]);
                }
            }
            System.out.print("Resposta: ");
            String respostaUsuario = sc.nextLine();

            if (pergunta.verificarResposta(respostaUsuario)) {
                Player.setPontos(Player.getPontos() + pergunta.getPontos());
                writer.write("Resposta do jogador:"+respostaUsuario+"\n");
                System.out.println("Resposta correta! Você ganhou " + pergunta.getPontos() + " pontos.");
                writer.write("Resposta correta! Você ganhou " + pergunta.getPontos() + " pontos."+ "\n\n");
            } else {
                writer.write("Resposta do jogador:"+respostaUsuario+"\n");
                System.out.println("Resposta incorreta! A resposta correta era: " + pergunta.getResposta());
                writer.write("Resposta incorreta! A resposta correta era: " + pergunta.getResposta()+ "\n\n");
            }

        }

        writer.write("Pontuação final do jogador " + Player.getNome() + ": " + Player.getPontos() + "\n");
        System.out.println("O arquivo de texto "+save+" foi gerado com sucesso!");
        System.out.println("Pontuação final do jogador " + Player.getNome() + ": " + Player.getPontos());
    } catch (IOException e) {
        System.out.println("Erro ao escrever o arquivo de texto"+save);
        e.printStackTrace();


        }
    }
}









