public class Pergunta {
    private String pergunta;
    private String resposta;
    private int Pontos;

    public Pergunta() {
    }

    public Pergunta(String pergunta, String resposta, int Pontos) {
        this.pergunta = pergunta;
        this.resposta = resposta;
        this.Pontos = Pontos;
    }

    public String getPergunta() {
        return pergunta;
    }

    public void setPergunta(String pergunta) {
        this.pergunta = pergunta;
    }

    public String getResposta() {
        return resposta;
    }

    public void setResposta(String resposta) {
        this.resposta = resposta;
    }

    public int getPontos() {
        return Pontos;
    }

    public void setPontos(int Pontos) {
        this.Pontos = Pontos;
    }

    public boolean verificarResposta(String respostaJogador) {
        return respostaJogador.equalsIgnoreCase(resposta);
    }
}
